// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once

#include "Engine/GameInstance.h"
#include "Online/FGOnlineHelpers.h"
#include "OnlineSessionSettings.h"
#include "TimerManager.h"
#include "Interfaces/OnlineSessionInterface.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Application/IInputProcessor.h" // <FL> [WuttkeP] Added input pre-processor for automatically updating the last used input device type.
#include "Online/OnlineServices.h"
#include "Online/Sessions.h"
#include "FGGameInstance.generated.h"

class FWidgetPath;
// <FL> ZimmermannA For usage outside of game instance
extern TAutoConsoleVariable< bool > CVarForceMouseAndKeyboardDeviceType;
extern TAutoConsoleVariable< bool > CVarForceGamepadDeviceType;

// <FL> [ZimmermannA] Used for the SteamDeck version

class FSlateSingleUserInputMapping : public ISlateInputManager
{
public:
	virtual int32 GetUserIndexForMouse() const override { return 0; }
	virtual int32 GetUserIndexForKeyboard() const override { return 0; }
	virtual FInputDeviceId GetInputDeviceIdForMouse() const override { return IPlatformInputDeviceMapper::Get().GetDefaultInputDevice(); }
	virtual FInputDeviceId GetInputDeviceIdForKeyboard() const override
	{
		return IPlatformInputDeviceMapper::Get().GetDefaultInputDevice();
	}
	virtual int32 GetUserIndexForController( int32 ControllerId ) const override { return 0; }
	virtual TOptional< int32 > GetUserIndexForController( int32 ControllerId, FKey InKey ) const override { return 0; }
	virtual TOptional< int32 > GetUserIndexForInputDevice( FInputDeviceId InputDeviceId ) const override { return 0; }

	virtual ~FSlateSingleUserInputMapping() = default;
};
// </FL>

UENUM(BlueprintType)
enum class EInputDeviceMode : uint8
{
	InputDeviceMode_MouseAndKeyboardAndGamepad	UMETA(DisplayName="MouseAndKeyboardAndGamepad"),
	InputDeviceMode_MouseAndKeyboard			UMETA(DisplayName="MouseAndKeyboard"),
	InputDeviceMode_Gamepad						UMETA(DisplayName="Gamepad")
};
// </FL>

class IFGDedicatedServerInterface;

UENUM(BlueprintType)
enum class EJoinSessionState : uint8
{
	JSS_NotJoiningSession,
	JSS_WaitingForLoginToComplete,
	JSS_QueryingHostsId,
	JSS_DestroyingOldSession,
	JSS_ConnectingToHost
};

// <FL> [WuttkeP] Added types for input device type detection and switching.
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam( FFGOnActiveInputDeviceTypeChanged, EInputDeviceType, newDeviceType );
DECLARE_DYNAMIC_DELEGATE_OneParam( FFGInputDeviceTypeChangedDelegate, EInputDeviceType, newDeviceType);
// </FL>

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam( FOnJoinSessionStateChanged, EJoinSessionState, newState );

// Used for reaching through the SlateApplication focus changed event to blueprints.
DECLARE_DYNAMIC_MULTICAST_DELEGATE( FFGOnFocusChanged );
// Used to allow external assets to be preloaded as a part of the asset preloading pass
DECLARE_MULTICAST_DELEGATE_OneParam( FFGGatherAssetsForPreloadDelegate, TArray<FSoftObjectPath>& /* OutAssetsToPreload */ );

USTRUCT()
struct FOnJoinSessionData
{
	GENERATED_BODY()

	void Init( class UFGLocalPlayer* player, const FOnlineSessionSearchResult& session )
	{
		LocalPlayer = player;
		Session = session;

		JoinInProgress = true;
	}

	void Done()
	{
		JoinInProgress = false;
		LocalPlayer = nullptr;
	}

	void SetState( EJoinSessionState newState, FOnJoinSessionStateChanged& onStateChangedDelegate );

	FORCEINLINE EJoinSessionState GetState() const { return State; }

	/** Player that want to join the session */
	UPROPERTY()
	TObjectPtr<class UFGLocalPlayer> LocalPlayer;

	/** Session to join */
	FOnlineSessionSearchResult Session;

	/** True if we are currently joining a session */
	uint8 JoinInProgress:1;
private:
	EJoinSessionState State;
};

/**
*
*/
USTRUCT( BlueprintType )
struct FFGModPackage
{
	GENERATED_BODY()

	UPROPERTY( BlueprintReadWrite, Category = "Modding" )
	FName ModPath;

	UPROPERTY( BlueprintReadWrite, Category = "Modding" )
	bool HasFGMods;

	UPROPERTY( BlueprintReadWrite, Category = "Modding" )
	FString Author;

	UPROPERTY( BlueprintReadWrite, Category = "Modding" )
	FString Version;

	UPROPERTY( BlueprintReadWrite, Category = "Modding" )
	FString Description;

	FFGModPackage()
	{
		ModPath = FName( TEXT( "" ) );
		HasFGMods = false;
		Author = TEXT( "" );
		Version = TEXT( "" );
		Description = TEXT( "" );
	}
};

USTRUCT( BlueprintType )
struct FFGGameNetworkErrorMsg
{
	GENERATED_BODY()
	FFGGameNetworkErrorMsg( ENetworkFailure::Type _errorType, const FString& _errorMsg ) : errorType( _errorType ), errorMsg( _errorMsg )
	{}
	FFGGameNetworkErrorMsg( ) : errorType( -1 ), errorMsg( "No errors" )
	{}
	UPROPERTY( BlueprintReadWrite)
	TEnumAsByte<ENetworkFailure::Type> errorType;

	UPROPERTY( BlueprintReadWrite )
	FString errorMsg;
};

/** Used to store the encryption data for the outgoing connection from the client to the dedicated server */
struct FFGPendingConnectionEncryptionData
{
	/** Encryption token that is associated to this encryption data. Used to make sure we do not use a wrong token. */
	FString EncryptionToken;
	/** Encryption data to use for encrypting the connection */
	FEncryptionData EncryptionData;
};

// Don't pass the error here, as we want the user to specify how it want to handle the error itself (peek or get)
DECLARE_DYNAMIC_MULTICAST_DELEGATE( FOnNewError );
/** Delegate when a network error has occured, like mismatching version, timeouts and so on */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams( FOnNetworkErrorRecieved, ENetworkFailure::Type, errorType, FString, errorMsg );

class UFGLocalPersistenceStore;
	/**
 * @OSS: Responsibilities:
 * - QueryNATType:
 * This queries the backend systems what kind of NAT they think we have. Doesn't always succeed
 * - Joining Sessions
 * We have two ways of joining sessions, invites or through joining someones presence. This is done through the UGameInstance::JoinSession
 * call. This will automatically tear down our current session. Leave the current game and join the new session
 */
UCLASS()
class FACTORYGAME_API UFGGameInstance : public UGameInstance, public FTickableGameObject
{
	GENERATED_BODY()
public:
	// Begin UGameInstance interface
	virtual void Init() override;
	virtual void StartGameInstance() override;
	virtual bool JoinSession( ULocalPlayer* localPlayer, const FOnlineSessionSearchResult& searchResult ) override;
	virtual void ReceivedNetworkEncryptionAck(const FOnEncryptionKeyResponse& Delegate) override;
	virtual void ReceivedNetworkEncryptionToken(const FString& EncryptionToken, const FOnEncryptionKeyResponse& Delegate) override;
	virtual EEncryptionFailureAction ReceivedNetworkEncryptionFailure(UNetConnection* Connection) override;
#if WITH_EDITOR
	virtual FGameInstancePIEResult InitializeForPlayInEditor(int32 PIEInstanceIndex, const FGameInstancePIEParameters& Params) override;
#endif
	// End UGameInstance interface

	//FTickableGameObject
	virtual void Tick( float DeltaTime ) override;

	virtual ETickableTickType GetTickableTickType() const override { return ETickableTickType::Always; }
	virtual TStatId GetStatId() const override { return UObject::GetStatID();	 }
	virtual bool IsTickableWhenPaused() const { return true; }
	virtual bool IsTickableInEditor() const { return true; }
	//End FTickableGameObject
	
	/** Get the music manager */
	FORCEINLINE class UFGMusicManager* GetMusicManager() const{ return mMusicManager; }

	/** Access the save system */
	FORCEINLINE class UFGSaveSystem* GetSaveSystem() const{ return mSaveSystem; }

	/** @return OnlineSession class to use for this game instance  */
	virtual TSubclassOf<UOnlineSession> GetOnlineSessionClass() override;
	
	// @todo: Move error functions to a "message bus" class	
	/** Pushes a error to the game, that handles it appropriately */
	void PushError( TSubclassOf<class UFGErrorMessage> errorMessage );

	/** Pushes a error to the game, that handles it appropriately */
	UFUNCTION( BlueprintCallable, Category="FactoryGame|ErrorHandling", meta=(DefaultToSelf = "worldContext"))
	static void PushError( UObject* worldContext, TSubclassOf<class UFGErrorMessage> errorMessage );
	
	/** Get the next error and removes it from the error queue, returns null when there is no more errors */
	class UFGErrorMessage* GetNextError();

	/** Get the next error and removes it from the error queue, returns null when there is no more errors */
	UFUNCTION( BlueprintCallable, Category="FactoryGame|ErrorHandling", meta=(DefaultToSelf = "worldContext"))
	static class UFGErrorMessage* GetNextError( UObject* worldContext );

	/** Peek at the next error and keep it in the error queue, returns null when there is no more errors */
	class UFGErrorMessage* PeekNextError() const;

	/** Peek at the next error and keep it in the error queue, returns null when there is no more errors */
	UFUNCTION( BlueprintPure, Category="FactoryGame|ErrorHandling", meta=(DefaultToSelf = "worldContext"))
	static class UFGErrorMessage* PeekNextError( UObject* worldContext );

	/** Marks that the player has seen alpha info screen */
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|Settings" )
	void SetHasSeenAlphaInfoScreen();

	/** Has the player seen the alpha info screen? */
	UFUNCTION( BlueprintPure, Category = "FactoryGame|Settings" )
	bool ShouldShowAlphaInfoScreen() const;

	// Finds non-original content and populates ModPackages
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|Modding" )
	bool FindModPackages();

	// Populates UGC arrays with data from ModPackages, Updates ModPackages Information with contents
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|Modding" )
	void GetFGUGC( UClass* WeaponClass, UClass* EnemyClass, UClass* BossClass, UClass *PlayerPawnClass );

	// Called when exiting to desktop/shutting down
	virtual void Shutdown() override;

	/* returns true if there were an error, and fills in the enum and string. If there were no error the type and msg will be undefined, and the function returns false. To get the next message or reset the error state, call PopLatestNetworkError function*/
	UFUNCTION( BlueprintPure, Category = "FactoryGame|ErrorHandling" )
	bool GetLatestNetworkError( FFGGameNetworkErrorMsg& msg );

	/* Pops the latest network message, removing it from the queue and resetting the error state. If there is more messages left after the pop it will return true, otherwise false. */
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|ErrorHandling" )
	bool PopLatestNetworkError();

	UFUNCTION(BlueprintPure, Category="FactoryGame|Online")
	EJoinSessionState GetCurrentJoinSessionState() const;

	/** Get the instance of the debug overlay widget. Will create one if it doesn't exists. Might return null if we don't have a specificed debug overlay widget class */
	class UFGDebugOverlayWidget* GetDebugOverlayWidget();

	/** Returns the interface to the dedicated server specific functionality on the game instance level */
	IFGDedicatedServerInterface* GetDedicatedServerInterface() const;

	/** Updates the encryption data set for the pending client connection */
	void SetPendingConnectionEncryptionData( const FFGPendingConnectionEncryptionData& NewEncryptionData );

	/** Returns the currently active input device type */
	UFUNCTION( BlueprintPure, Category = "FactoryGame|UI" )
	EInputDeviceType GetActiveInputDeviceType() const;

	UFUNCTION( BlueprintCallable, Category = "FactoryGame|UI" )
	FString GetLastInputDeviceIdentifier() const { return mLastInputDeviceIdentifier; }
	
	/** Returns if the game is currently running on the steam deck. */
	UFUNCTION( BlueprintPure, Category = "FactoryGame|UI" )
	bool IsRunningOnSteamDeck() const;

	/** Listener delegate is called by the SlateApplication. The OnFocusChanged delegate can be bound to in blueprint. */
	UPROPERTY( BlueprintAssignable, Category = "FactoryGame|UI" )
	FFGOnFocusChanged mOnFocusChangedDelegate;
	FDelegateHandle mOnFocusChangedListenerDelegate;

	/** Returns the common user subsystem for this game instance */
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|Online" )
	class UCommonUserSubsystem* GetCommonUserSubsystem() const;

	//<FL> [VilagosD] store the player avatar textures so we don't have to download them everytime 
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|Online" )
	const UTexture* GetCachedAvatarTexture(const FString& avatarURL);
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|Online"  )
	void AddAvatarToTextureCache( const FString& avatarURL, UTexture* texture );

	/** Add a callback to the input device type changed event and immediately call it, for convenience. */
	UFUNCTION( BlueprintCallable, Category = "FactoryGame|UI"  )
	void AddAndCallDeviceTypeChangedCallback( UPARAM(DisplayName="Event") FFGInputDeviceTypeChangedDelegate Delegate);
protected:
	// Called when a map has loaded properly in Standalone
	virtual void LoadComplete( const float loadTime, const FString& mapName ) override;

	/** Called after we have destroyed a old session for joining a new session */
	virtual void OnDestroyOldSessionComplete_JoinSession( FName gameSessionName, bool wasSuccessful );

	/** Called after we have queried a friends product id */
	virtual void OnQueryFriendProductIdCompleted_JoinSession( bool wasSuccessful, FString EpicId, struct EOS_ProductUserIdDetails* ProductId );

	/** Called after we have queried a friends product id */
	UFUNCTION()
	virtual void PollHostProductUserId_JoinSession();

	UFUNCTION()
	void OnUISessionJoinWasRequested( UOnlineIntegrationBackend* Backend );

	/** Called after we have joined a session, makes sure we copy the session settings from the host */
	void OnJoinSessionComplete( FName sessionName, EOnJoinSessionCompleteResult::Type joinResult );

	UFUNCTION()
	void OnAnyUISessionJoinWasRequestedOnBackend( UOnlineIntegrationBackend* Backend );

	void SendRecievedNetworkErrorOnDelegate( UWorld* world, UNetDriver* driver, ENetworkFailure::Type errorType, const FString& errorMsg );
	void SwitchActiveInput( EInputDeviceType deviceType );

	void OnLastInputDeviceTypeChanged( EInputDeviceType deviceType, const FInputEvent& InputEvent );

	/** Called to preload assets for this game instance */
	void PreloadAssetsForGameInstance();

private:
	void OnPackagePreloaded(const FName& PackageName, UPackage* LoadedPackage, EAsyncLoadingResult::Type Result, TArray<FSoftObjectPath> AssetsInPackage);
	void GatherDefaultAssetsForPreload(TArray<FSoftObjectPath>& OutAssetsToPreload);
	
	void OnPreLoadMap( const FString& levelName );

	/** Initializes the Game Analytics Service. Requires that the Epic Online Services handle has been created beforehand. */
	void InitGameAnalytics();
	void ShutdownGameAnalytics();

	/** Telemetry */
	void SubmitGameStartTelemetry() const;
	UFUNCTION()
	void SubmitNetModeTelemetry( UWorld* world ) const;
	void SubmitModTelemetry() const;

	void JoinSession_Internal();

protected:
	/** The global save system */
	UPROPERTY()
	TObjectPtr<class UFGSaveSystem> mSaveSystem;

	// @todo: Make accessors for this when moving this to FGErrorBus or similar
	/** Called whenever a new error is added that doesn't send you to main menu */
	UPROPERTY(BlueprintAssignable)
	FOnNewError mOnNewError;

	TArray< FFGGameNetworkErrorMsg > mNetworkErrorQueue;

	UPROPERTY( BlueprintAssignable )
	FOnNetworkErrorRecieved mOnNetworkErrorRecieved;
	
	/** List of errors that we should pop */
	UPROPERTY()
	TArray<TObjectPtr<class UFGErrorMessage>> mErrorList;

	/** Storing data for joining a session */
	UPROPERTY()
	FOnJoinSessionData mJoinSessionData;

	/** Called when the state of joining session has been updated */
	UPROPERTY(BlueprintAssignable)
	FOnJoinSessionStateChanged mOnJoinSessionStateUpdated;

	/** Join session complete handle */
	FDelegateHandle mOnJoinSessionCompleteHandle;
	
	/** Used to query NAT type, nothing more */
	EOS_HP2P mP2PHandle = nullptr;

	/** Encryption data for our pending connection to the DS */
	FFGPendingConnectionEncryptionData mPendingConnectionEncryptionData;

	EInputDeviceMode mInputDeviceMode = EInputDeviceMode::InputDeviceMode_MouseAndKeyboard;
	FString mLastInputDeviceIdentifier = "";
	FTimerHandle mIsGamepadAttachedTimer;
	FDelegateHandle mInputDeviceConnectionChangeHandle;
	FDelegateHandle mMouseEnteredViewportHandle;

	//<FL>[VilagosD] store the player avatar textures so we don't have to download them everytime 
	UPROPERTY()
	TMap< FString, TObjectPtr<UTexture> > mAvatarTextureCache;

#if( defined( PLATFORM_PS5 ) && PLATFORM_PS5 ) || ( defined( PLATFORM_XSX ) && PLATFORM_XSX )
	// Save time on suspention
	FDateTime SuspensionTime;
#endif

public:
	 FTimerManager& GetUITimerManager() { return mUITimerManager; }
	
	void SetInputDeviceMode(EInputDeviceMode InputDeviceMode, bool bForce = false);
	bool GetConsoleVariableBool(const char* Variable);
	void SetConsoleVariable(const char* Variable, bool Active);
	void UpdateStringTableVariants(bool UsingGamepad);

	bool IsApplicationInForeground() { return bIsApplicationInForeground; };

	UFUNCTION(BlueprintCallable, BlueprintPure)
	EInputDeviceMode GetInputDeviceMode() { return mInputDeviceMode; }

	// Mod packages found - valid or invalid
	UPROPERTY( BlueprintReadOnly, Category = "Modding" )
	TArray< FFGModPackage > ModPackages;

	/** Controlling our music since... 2018 */
	UPROPERTY()
	TObjectPtr<class UFGMusicManager> mMusicManager;

	/** Has the player seen the alpha info screen, used to only show it once per session */
	bool mHasSeenAlphaInfo;

	// <FL> [WuttkeP] Added callback for input device type switching.
	UPROPERTY( BlueprintAssignable, Category = "Input" )
	FFGOnActiveInputDeviceTypeChanged mOnActiveInputDeviceTypeChanged;
	// </FL>

	// <FL> [KonradA] Getter For Local Persistence store
	UFUNCTION(BlueprintCallable)
	UFGLocalPersistenceStore* GetLocalPersistenceStore();
	UPROPERTY(BlueprintReadWrite)
	bool bTraveledToMainMenuFromUserJoinFailure = false;

	// </FL>
	
	// <FL> [MartinC] Registry of all the aim assist targets currently available in the game
	UPROPERTY( BlueprintReadOnly, Category = "Aim" )
	TObjectPtr< class UFGAimTargetRegistry > AimTargetRegistry = nullptr;
	// </FL>

#if WITH_EDITOR
	/** If this game instance was started as a part of Play In Editor, this will cache the Server Port it is using */
	int32 mCachedPIEServerPort;
#endif
	TSet< FName > mPendingCanceledActivities; // <FL> [TranN] PS5 Activity
private:
	UPROPERTY()
	TObjectPtr<class UFGDebugOverlayWidget> mDebugOverlayWidget;

	//<FL>[KonradA] Helper store for key value pairs so that users can locally store data that does not need to be replicated
	UPROPERTY()
	TObjectPtr<UFGLocalPersistenceStore> mLocalPersistenceStore;
	//</FL>
	
	FTimerManager mUITimerManager;
	
	/** Mods and external subsystems can subscribe to this delegate to preload assets when the game instance is initialized and keep them in memory */
	static FFGGatherAssetsForPreloadDelegate GatherAssetsForPreload;

	/** Is called by the SlateApplication */
	void OnFocusChanged( const struct FFocusEvent& FocusEvent, const class FWeakWidgetPath& OldFocusedWidgetPath,
						 const TSharedPtr< class SWidget >& OldFocusedWidget, const FWidgetPath& NewFocusedWidgetPath,
						 const TSharedPtr< SWidget >& NewFocusedWidget );

	//<FL> [BGR] Handling for console Suspend/Resume state switches
#if( defined( PLATFORM_PS5 ) && PLATFORM_PS5 ) || ( defined( PLATFORM_XSX ) && PLATFORM_XSX )
	void HandleAppSuspend();
	void HandleAppResume();
#endif
	bool IsInMainMenu() const;

	UFUNCTION()
	void OnMpSessionExpiredConfirmed( bool ConfirmClicked );
	//<FL>

	// <FL> [WuttkeP] Setup and switching of input device mode
	void SetupInitialInputDeviceMode();

	UFUNCTION()
	void OnInputModeUpdated( FString cvar );
	UFUNCTION()
	void OnControllerConnectionChanged( EInputDeviceConnectionState NewConnectionState, FPlatformUserId UserID, FInputDeviceId InputDeviceId );
	UFUNCTION()
	void HandleMouseEnteredViewport();
	// </FL>

	uint32 GetLocalNetworkVersion();

	bool bIsApplicationInForeground = true;
};
