// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FGAttentionPingActor.generated.h"

UCLASS( Blueprintable )
class FACTORYGAME_API AFGAttentionPingActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AFGAttentionPingActor();

	virtual void BeginPlay() override;

	void GetLifetimeReplicatedProps( TArray<FLifetimeProperty>& OutLifetimeProps ) const override;

	/** Set the player state of the player that spawned this actor */
	void SetOwningPlayerState( class AFGPlayerState* playerState );

	/** player state of the player that spawned this actor */
	UFUNCTION( BlueprintPure, Category = "Attention Ping" )
	FORCEINLINE AFGPlayerState* GetOwningPlayerState() const { return mOwningPlayerState; }

	UFUNCTION()
	void OnRep_OwningPlayerState();
	
	/** Called when we have the player state replicated so now we can spawn the effects */
	UFUNCTION( BlueprintImplementableEvent, BlueprintCosmetic, Category = "Attention Ping" )
	void SpawnAttentionPingEffects();

protected:

	/** The player state of the pawn that spawned this actor */
	UPROPERTY( ReplicatedUsing = OnRep_OwningPlayerState )
	TObjectPtr<class AFGPlayerState> mOwningPlayerState;

	UPROPERTY( EditDefaultsOnly, Category = "Attention Ping" )
	TObjectPtr<UTexture2D> mCompassTexture;

	UPROPERTY( EditDefaultsOnly, Category = "Attention Ping" )
	float mLifeSpan = 10.f;

	UPROPERTY( EditDefaultsOnly, Category = "Attention Ping" )
	float mActorRepresentationLifeSpan = 5.f;
	
};
